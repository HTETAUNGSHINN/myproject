<?php include ('session.php');?>	
<?php include ('header.php');?>	
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">YANGON</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">YANGON</a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
              
                <li class="dropdown"> 
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                      						
					 Welcome : Administrator
                    </a>
                  
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
						
						<div id="tooplate_main">

        <button class="btn btn-warning btn-lg" data-toggle="modal" data-target="#myModal">
                              ORDER VIEWS FORMS
      </button>
      </br>
      </br>
       <table border="4">
                    
                    <tr><th width="100px" height="50px">ID:</th>                    
                        <th width="100px" height="50px">Product NO:</th>
                        <th width="100px" height="50px">Price:</th>
                        <th width="100px" height="50px">Name:</th>
                        <th width="100px" height="50px">Phone:</th>
                        <th width="100px" height="50px">Address:</th>   
                        <th width="100px" height="50px">Order No:</th>                      
                     </tr>  
                     <?php
                     error_reporting(1);
                     include("connect.php");
                        $sel=mysql_query("select * from orders ");
                        while($row=mysql_fetch_array($sel))
                            {       
                                    $id=$row['ord_id'];                 
                                    $prodno=$row['productno'];
                                    $price=$row['price'];
                                    $name=$row['name'];
                                    $phone=$row['phone'];
                                    $address=$row['address'];
                                    $ordno=$row['order_no'];
                        ?>
                     <tr>
                        
                        <td width="100px" height="50px"><?php echo $id; ?></td>
                        <td width="100px" height="50px"><?php echo $prodno; ?></td>
                        <td width="100px" height="50px"><?php echo $price; ?></td>
                        <td width="100px" height="50px"><?php echo $name; ?></td>
                        <td width="100px" height="50px"><?php echo $phone; ?></td>
                        <td width="100px" height="50px"><?php echo $address; ?></td>
                        <td width="100px" height="50px"><?php echo $ordno; ?></td>
                        
                        
                                                
                      </tr>         
                    <?php                 
                            }   
                    ?>
                    </table>
       </center>
                
				
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
   <?php include ('script.php');?>
</body>
</html>
