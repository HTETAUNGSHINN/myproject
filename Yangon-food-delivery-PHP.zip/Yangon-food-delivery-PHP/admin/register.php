<?php include ('session.php');?>	
<?php include ('header.php');?>	
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">YANGON</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">YANGON</a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
              
                <li class="dropdown"> 
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                      						
					 Welcome : Administrator
                    </a>
                  
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
       <?php include ('nav_sidebar.php');?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
						
						
						
        <div id="tooplate_main">

		<button class="btn btn-warning btn-lg" data-toggle="modal" data-target="#myModal">
                              REGISTER VIEWS FORMS
      </button>
      </br>
      </br>
       <table border="3" >
					
					<tr><th width="100px" height="50px">First_Name:</th>					
						<th width="100px" height="50px">Last_Name:</th>
						<th width="100px" height="50px">Email:</th>
						<th width="100px" height="50px">Password:</th>
						<th width="100px" height="50px">Phone:</th>
                        <th width="100px" height="50px">Country:</th>
                        <th width="100px" height="50px">City:</th>
                        <th width="100px" height="50px">Townsip:</th>
                        								
					 </tr>	
					
<?php

	error_reporting(1);
	include("connect.php");
    $sel=mysql_query("select * from sign_up ");
						while($row=mysql_fetch_array($sel))
                    {
                        $first_name=$row['first_name'];
                        $last_name=$row['last_name'];
                        $email=$row['email'];
                        $password=$row['password'];
                        $phone_no=$row['phone_no'];
                        $country=$row['country'];
                        $city=$row['city'];
                        $township=$row['township'];                   
	
?>
					 <tr>
						
						<td width="100px" height="50px"><?php echo $first_name; ?></td>
						<td width="100px" height="50px"><?php echo $last_name; ?></td>
						<td width="100px" height="50px"><?php echo $email; ?></td>
						<td width="100px" height="50px"><?php echo $password; ?></td>
						<td width="100px" height="50px"><?php echo $phone_no; ?></td>
                        <td width="100px" height="50px"><?php echo $country; ?></td>
                        <td width="100px" height="50px"><?php echo $city; ?></td>
                        <td width="100px" height="50px"><?php echo $township; ?></td>
                       
						
						
												
					  </tr>	
                      <?php
                    }
                      ?>
                    
					</table>
				
				</div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
   <?php include ('script.php');?>
</body>
</html>
